Insert into LPU_MOVIE_THEATRE(theatre_Id,theatre_Name,theatre_city,manager_Name,manager_Contact) values(1, 'a','jalandhar','ram',9875642548);
Insert into LPU_MOVIE_THEATRE(theatre_Id,theatre_Name,theatre_city,manager_Name,manager_Contact) values(2, 'b','jalandhar','sam',7896541256);
Insert into LPU_MOVIE_THEATRE(theatre_Id,theatre_Name,theatre_city,manager_Name,manager_Contact) values(3, 'c','phagwara','shyam',7568945211);
Insert into LPU_MOVIE_THEATRE(theatre_Id,theatre_Name,theatre_city,manager_Name,manager_Contact) values(4, 'd','phagwara','singh',8974561258);
Insert into LPU_MOVIE_THEATRE(theatre_Id,theatre_Name,theatre_city,manager_Name,manager_Contact) values(5, 'e','amritsar','harpal',6548974586);

select * from LPU_MOVIE_THEATRE;


insert into LPU_MOVIE_MOVIE(movie_Id,movie_Name,language,director,genre) values(1001,'bahubali','telugu','ssr','action');
insert into LPU_MOVIE_MOVIE(movie_Id,movie_Name,language,director,genre) values(1002,'war','hindi','karan','action');
insert into LPU_MOVIE_MOVIE(movie_Id,movie_Name,language,director,genre) values(1003,'kgf','kannada','prashanth','action');
insert into LPU_MOVIE_MOVIE(movie_Id,movie_Name,language,director,genre) values(1004,'wfl','telugu','vd','Romantic');
insert into LPU_MOVIE_MOVIE(movie_Id,movie_Name,language,director,genre) values(1005,'hit','telugu','sudheer','thriller');

select * from LPU_MOVIE_MOVIE;
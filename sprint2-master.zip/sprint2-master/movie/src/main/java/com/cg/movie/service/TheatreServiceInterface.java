package com.cg.movie.service;

public interface TheatreServiceInterface {
	public String theatreName(int theatreId);
}

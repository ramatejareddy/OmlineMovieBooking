package com.cg.movie.Dao;

public interface TheatreDaoInterface {
	public String gettheatreName(int theatreId);
}

package com.cg.movie.Exception;

public class TheatreException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TheatreException(String msg) {
		super(msg);
	}
}

package com.cg.movie.service;

public interface BookingServiceInterface {
	public double totalCost(int seatId,int noOfSeats);
	

}

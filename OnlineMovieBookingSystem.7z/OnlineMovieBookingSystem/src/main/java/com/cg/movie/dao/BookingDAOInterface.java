package com.cg.movie.dao;

public interface BookingDAOInterface {
	public double getPrice(int seatId);
	

}

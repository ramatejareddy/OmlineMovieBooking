package com.cg.movie.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.movie.dao.BookingDAOInterface;
@Service
@Transactional
public class BookingService implements BookingServiceInterface {

	
	@Autowired
	BookingDAOInterface dao;
	@Override
	public double totalCost(int seatId,int noOfSeats) {
		double seatPrice=dao.getPrice(seatId);
		double totalPrice= noOfSeats*seatPrice;
		
		return totalPrice;
	}

}
